﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
//Cổng số 1
class Message
{
    ConnectSQL objConnect = new ConnectSQL();

    public int UpdateMessage(string MESSAGE_ID)
    {
        string stored = "tblTransaction_Update_IsSent";
        string[] para = { "@MESSAGE_ID" };
        object[] objV = { MESSAGE_ID };
        return objConnect.ExcuteStored(stored, para, objV);

    }
    public DataTable tblMessage_Select_Top1()
    {
        string stored = "tblTransaction_PartityID_Chan";
        return objConnect.TableWithoutParameter(stored).Tables[0];
    }
    public DataTable tblMessage_Select_All()
    {
        string stored = "tblTransaction_All";
        return objConnect.TableWithoutParameter(stored).Tables[0];
    }
    public DataSet getSttIP(string ip) 
    {
        try
        {
            string store = "get_tblPingIP";
            string[] para = { "@ip" };
            object[] objVal = { ip };
            DataSet ds = objConnect.DataSetWithParameter(store, para, objVal);
            return ds;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }










}
