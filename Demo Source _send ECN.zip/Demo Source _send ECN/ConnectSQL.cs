﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Data.SqlClient;


/// <summary>
/// Summary description for ConnectSQL
/// </summary>
public class ConnectSQL
{
    public ConnectSQL()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    //public string connnectionString = ConfigurationManager.ConnectionStrings["VietHungPharmaConnectionString"].ConnectionString;


    public string ConstringAppConfig()
    {
        return @"Data Source=192.168.128.1;Initial Catalog=SMSVersion3;Persist Security Info=True;User ID=sa;Password=Psnvdb2013";//SMSapplication.Properties.Settings.Default.SMSApplicationConnectionString;
        //return @"Data Source=(localdb)\Duong;Initial Catalog=SMSVersion3_1;Persist Security Info=True;User ID=Admin;Password=123456";//SMSapplication.Properties.Settings.Default.SMSApplicationConnectionString;
    }



    SqlConnection cnn;
    SqlCommand cmd;

    public void OpenConnection()
    {

        cnn = new SqlConnection(ConstringAppConfig());
        if (cnn.State == ConnectionState.Closed)
        {
            cnn.Open();
        }
    }
    public void CloseConnection()
    {

        if (cnn.State == ConnectionState.Open)
            cnn.Close();


    }
    public void ExcutedCMD(string cmdText)
    {

        OpenConnection();
        cmd = new SqlCommand(cmdText, cnn);
        int a = cmd.ExecuteNonQuery();

        CloseConnection();


    }
    public int ExcuteStored(string storedname, string[] parameter, object[] objVal)
    {

        OpenConnection();
        cmd = new SqlCommand(storedname, cnn);
        cmd.CommandType = CommandType.StoredProcedure;
        for (int i = 0; i < parameter.Length; i++)
        {
            cmd.Parameters.Add(new SqlParameter(parameter[i], objVal[i]));
        }
        int a = cmd.ExecuteNonQuery();
        CloseConnection();
        return a;


    }
    public string GetExcuteScalar(string storedname, string[] parameter, object[] objVal)
    {

        OpenConnection();
        cmd = new SqlCommand(storedname, cnn);
        cmd.CommandType = CommandType.StoredProcedure;
        for (int i = 0; i < parameter.Length; i++)
        {
            cmd.Parameters.Add(new SqlParameter(parameter[i], objVal[i]));
        }
        string result = cmd.ExecuteScalar().ToString();
        CloseConnection();
        return result;


    }
    public DataTable TableWithParameter(string storedname, string[] parameter, object[] objVal)
    {
        OpenConnection();
        cmd = new SqlCommand(storedname, cnn);
        cmd.CommandType = CommandType.StoredProcedure;
        for (int i = 0; i < parameter.Length; i++)
        {
            cmd.Parameters.Add(new SqlParameter(parameter[i], objVal[i]));
        }
        DataTable db = new DataTable();
        SqlDataAdapter da = new SqlDataAdapter();

        da.SelectCommand = cmd;
        da.Fill(db);
        CloseConnection(); return db;
    }
    public DataSet DataSetWithParameter(string storedname, string[] parameter, object[] objVal)
    {
        OpenConnection();
        cmd = new SqlCommand(storedname, cnn);
        cmd.CommandType = CommandType.StoredProcedure;
        for (int i = 0; i < parameter.Length; i++)
        {
            cmd.Parameters.Add(new SqlParameter(parameter[i], objVal[i]));
        }
        DataSet db = new DataSet();
        SqlDataAdapter da = new SqlDataAdapter();

        da.SelectCommand = cmd;
        da.Fill(db);
        CloseConnection(); return db;
    }
    public DataSet DataSetWithoutParameter(string storedname)
    {
        OpenConnection();
        cmd = new SqlCommand(storedname, cnn);
        cmd.CommandType = CommandType.StoredProcedure;
        DataSet db = new DataSet(); SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        da.Fill(db);
        CloseConnection(); return db;
    }
    public DataSet TableWithoutParameter(string storedname)
    {
        OpenConnection();
        cmd = new SqlCommand(storedname, cnn);
        cmd.CommandType = CommandType.StoredProcedure;
        DataSet db = new DataSet(); SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        da.Fill(db);
        CloseConnection(); return db;
    }
    public object GetExcuteScalar(string sql)
    {
        object t = "";
        OpenConnection();
        cmd = new SqlCommand(sql, cnn);
        t = cmd.ExecuteScalar();
        CloseConnection();
        return t;
    }
    public DataTable GetTableWithCommandText(string sql)
    {
        OpenConnection();
        cmd = new SqlCommand(sql, cnn);

        DataTable db = new DataTable(); SqlDataAdapter da = new SqlDataAdapter();
        da.SelectCommand = cmd;
        da.Fill(db);
        CloseConnection(); return db;
    }

    public int insert(string storedname, string[] arrParam, object[] arrValue)
    {
        int id = 0;
        try
        {
            OpenConnection();
            cmd = new SqlCommand(storedname, cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterID = new SqlParameter("@ID", 0);
            parameterID.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parameterID);

            for (int i = 0; i < arrParam.Length; i++)
            {
                cmd.Parameters.Add(new SqlParameter(arrParam[i], arrValue[i]));
            }

            cmd.ExecuteNonQuery();
            id = Int32.Parse(cmd.Parameters["@ID"].Value.ToString());
            CloseConnection();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return id;
    }




    public int insertMessageID(string storedname, string[] arrParam, object[] arrValue)
    {
        int id = 0;
        try
        {
            OpenConnection();
            cmd = new SqlCommand(storedname, cnn);
            cmd.CommandType = CommandType.StoredProcedure;

            SqlParameter parameterID = new SqlParameter("@MESSAGE_ID", 0);
            parameterID.Direction = ParameterDirection.Output;
            cmd.Parameters.Add(parameterID);

            for (int i = 0; i < arrParam.Length; i++)
            {
                cmd.Parameters.Add(new SqlParameter(arrParam[i], arrValue[i]));
            }

            cmd.ExecuteNonQuery();
            id = Int32.Parse(cmd.Parameters["@MESSAGE_ID"].Value.ToString());
            CloseConnection();
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return id;
    }




    public bool Update(string storedname, string[] arrParam, object[] arrValue)
    {
        bool kt = false;
        try
        {
            OpenConnection();
            cmd = new SqlCommand(storedname, cnn);
            cmd.CommandType = CommandType.StoredProcedure;
            for (int i = 0; i < arrParam.Length; i++)
            {
                cmd.Parameters.Add(new SqlParameter(arrParam[i], arrValue[i]));
            }
            cmd.ExecuteNonQuery();
            CloseConnection();
            kt = true;
        }
        catch (Exception ex)
        {
            kt = false;
            throw ex;
        }
        return kt;
    }

    public string WriteXML(DataTable objDT)
    {
        string sNew = "";
        sNew = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>";
        sNew += "<root>";
        if (objDT.Rows.Count > 0)
        {

            for (int i = 0; i < objDT.Rows.Count; i++)
            {
                sNew += "<Row id='" + i + "'>";
                for (int j = 0; j < objDT.Columns.Count; j++)
                {
                    sNew += "<" + objDT.Columns[j].ToString() + ">";
                    sNew += "<![CDATA[" + objDT.Rows[i][j].ToString() + " ]]>";
                    sNew += "</" + objDT.Columns[j].ToString() + ">";
                }
                sNew += "</Row>";
            }
        }
        else
        {
            sNew += "<Rows>0</Rows>";
        }
        sNew += "</root>";
        return sNew;
    }


    // cat chuoi
    public string CutString(string param, int param1)
    {
        string strCut;
        string strFinish = "";
        if (param.Length > param1)
        {
            strCut = param.Substring(0, param1);
            string[] arr = strCut.Split(new char[] { ' ' }, param1);

            for (int i = 0; i < arr.Length - 1; i++)
            {
                strFinish += arr[i] + " ";
            }

            strFinish = strFinish + " ...";
        }
        else
        {
            strFinish = param;
        }

        return strFinish;

    }

}
