/*=====================================================================
  File:      frmDemo.cs

  Summary:   Main form for GSMComm Demo application. Demonstrates how
             to use GSMComm for various operations.

---------------------------------------------------------------------

This source code is intended only as a supplement to the GSMComm
development package or on-line documentation and may not be distributed
separately.
=====================================================================*/

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

using System.Runtime.Remoting.Channels;
using System.Runtime.Remoting.Channels.Tcp;

using GsmComm.PduConverter;
using GsmComm.PduConverter.SmartMessaging;
using GsmComm.GsmCommunication;
using GsmComm.Interfaces;
using System.Collections.Generic;
using System.Net.NetworkInformation;

namespace GSMCommDemo
{
    /// <summary>
    /// The main form for the GSMComm demo.
    /// </summary>
    public class frmDemo : System.Windows.Forms.Form
    {
        private IContainer components;

        private System.Windows.Forms.TextBox txtOutput;
        private System.Windows.Forms.CheckBox chkEnableLogging;
        private System.Windows.Forms.Button txtClearOutput;
        private System.Windows.Forms.Label lblNotConnected;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;

        private GsmCommMain comm;
        private bool registerMessageReceived;
        private SecuritySettings remotingSecurity;
        private TabPage tabNetwork;
        private Button btnSubscriberNumbers;
        private Button btnListOperators;
        private Button GetOpSelectionMode;
        private Button GetOperator;
        private TabPage tabPhonebook;
        private Button btnPbMemStatus;
        private Button btnPbStorages;
        private Label label9;
        private TextBox txtDelPbIndex;
        private TextBox txtPbNumber;
        private TextBox txtPbName;
        private Label label7;
        private Label label6;
        private Button btnCreatePbEntry;
        private Label label5;
        private RadioButton rbPhonebookPhone;
        private RadioButton rbPhonebookSIM;
        private Button btnExportPhonebook;
        private Button btnImportPhonebook;
        private Button btnDumpPhonebook;
        private Button btnDeletePhonebookEntry;
        private Button btnDeletePhonebook;
        private TabPage tabManageSMS;
        private Panel panel2;
        private RadioButton rbExportBinary;
        private RadioButton rbExportText;
        private Label label20;
        private TextBox txtNewSMSCType;
        private TextBox txtNewSMSC;
        private TextBox txtDelMsgIndex;
        private CheckBox chkNewSMSCType;
        private Button btnGetSMSC;
        private Button btnSetSMSC;
        private Button btnMsgMemStatus;
        private Label label8;
        private Label label4;
        private Button btnReadMessages;
        private Button btnDelMessage;
        private Button btnDelAllMsgs;
        private Button btnMsgStorages;
        private Button btnMsgNotification;
        private Button btnMsgNotificationOff;
        private Button btnMsgRoutingOn;
        private Button btnMsgRoutingOff;
        private Button btnCopyMessages;
        private Button btnExportMessages;
        private Button btnImportMessages;
        private RadioButton rbMessagePhone;
        private RadioButton rbMessageSIM;
        private TabPage tabSendSMS;
        private GroupBox groupBox1;
        private TextBox txtDestinationPort;
        private CheckBox chkDestinationPort;
        private CheckBox chkSmsBatchMode;
        private Label label19;
        private TextBox txtSendTimes;
        private CheckBox chkMultipleTimes;
        private CheckBox chkSMSC;
        private CheckBox chkUnicode;
        private CheckBox chkReport;
        private CheckBox chkAlert;
        private TextBox txtSMSC;
        private Button btnSendMessage;
        private TextBox txtNumber;
        private TextBox txtMessage;
        private Label label2;
        private Label label1;
        private TabPage tabGeneral;
        private TextBox txtPin;
        private Button btnEnterPin;
        private Button btnGetPinStatus;
        private Button btnBatteryCharge;
        private Button btnSignalQuality;
        private Button btnIdentify;
        private Button btnIsConnected;
        private Button btnReset;
        private TabControl tabControl;
        private Timer timer1;

        private delegate void SetTextCallback(string text);
        private IProtocol protocolLevel;

        public frmDemo()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();

            this.comm = null;
            this.registerMessageReceived = false;

            this.remotingSecurity = new SecuritySettings();
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                if (components != null)
                {
                    components.Dispose();
                }
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.txtOutput = new System.Windows.Forms.TextBox();
            this.chkEnableLogging = new System.Windows.Forms.CheckBox();
            this.txtClearOutput = new System.Windows.Forms.Button();
            this.lblNotConnected = new System.Windows.Forms.Label();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabNetwork = new System.Windows.Forms.TabPage();
            this.btnSubscriberNumbers = new System.Windows.Forms.Button();
            this.btnListOperators = new System.Windows.Forms.Button();
            this.GetOpSelectionMode = new System.Windows.Forms.Button();
            this.GetOperator = new System.Windows.Forms.Button();
            this.tabPhonebook = new System.Windows.Forms.TabPage();
            this.btnPbMemStatus = new System.Windows.Forms.Button();
            this.btnPbStorages = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.txtDelPbIndex = new System.Windows.Forms.TextBox();
            this.txtPbNumber = new System.Windows.Forms.TextBox();
            this.txtPbName = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.btnCreatePbEntry = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.rbPhonebookPhone = new System.Windows.Forms.RadioButton();
            this.rbPhonebookSIM = new System.Windows.Forms.RadioButton();
            this.btnExportPhonebook = new System.Windows.Forms.Button();
            this.btnImportPhonebook = new System.Windows.Forms.Button();
            this.btnDumpPhonebook = new System.Windows.Forms.Button();
            this.btnDeletePhonebookEntry = new System.Windows.Forms.Button();
            this.btnDeletePhonebook = new System.Windows.Forms.Button();
            this.tabManageSMS = new System.Windows.Forms.TabPage();
            this.panel2 = new System.Windows.Forms.Panel();
            this.rbExportBinary = new System.Windows.Forms.RadioButton();
            this.rbExportText = new System.Windows.Forms.RadioButton();
            this.label20 = new System.Windows.Forms.Label();
            this.txtNewSMSCType = new System.Windows.Forms.TextBox();
            this.txtNewSMSC = new System.Windows.Forms.TextBox();
            this.txtDelMsgIndex = new System.Windows.Forms.TextBox();
            this.chkNewSMSCType = new System.Windows.Forms.CheckBox();
            this.btnGetSMSC = new System.Windows.Forms.Button();
            this.btnSetSMSC = new System.Windows.Forms.Button();
            this.btnMsgMemStatus = new System.Windows.Forms.Button();
            this.label8 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.btnReadMessages = new System.Windows.Forms.Button();
            this.btnDelMessage = new System.Windows.Forms.Button();
            this.btnDelAllMsgs = new System.Windows.Forms.Button();
            this.btnMsgStorages = new System.Windows.Forms.Button();
            this.btnMsgNotification = new System.Windows.Forms.Button();
            this.btnMsgNotificationOff = new System.Windows.Forms.Button();
            this.btnMsgRoutingOn = new System.Windows.Forms.Button();
            this.btnMsgRoutingOff = new System.Windows.Forms.Button();
            this.btnCopyMessages = new System.Windows.Forms.Button();
            this.btnExportMessages = new System.Windows.Forms.Button();
            this.btnImportMessages = new System.Windows.Forms.Button();
            this.rbMessagePhone = new System.Windows.Forms.RadioButton();
            this.rbMessageSIM = new System.Windows.Forms.RadioButton();
            this.tabSendSMS = new System.Windows.Forms.TabPage();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txtDestinationPort = new System.Windows.Forms.TextBox();
            this.chkDestinationPort = new System.Windows.Forms.CheckBox();
            this.chkSmsBatchMode = new System.Windows.Forms.CheckBox();
            this.label19 = new System.Windows.Forms.Label();
            this.txtSendTimes = new System.Windows.Forms.TextBox();
            this.chkMultipleTimes = new System.Windows.Forms.CheckBox();
            this.chkSMSC = new System.Windows.Forms.CheckBox();
            this.chkUnicode = new System.Windows.Forms.CheckBox();
            this.chkReport = new System.Windows.Forms.CheckBox();
            this.chkAlert = new System.Windows.Forms.CheckBox();
            this.txtSMSC = new System.Windows.Forms.TextBox();
            this.btnSendMessage = new System.Windows.Forms.Button();
            this.txtNumber = new System.Windows.Forms.TextBox();
            this.txtMessage = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.tabGeneral = new System.Windows.Forms.TabPage();
            this.txtPin = new System.Windows.Forms.TextBox();
            this.btnEnterPin = new System.Windows.Forms.Button();
            this.btnGetPinStatus = new System.Windows.Forms.Button();
            this.btnBatteryCharge = new System.Windows.Forms.Button();
            this.btnSignalQuality = new System.Windows.Forms.Button();
            this.btnIdentify = new System.Windows.Forms.Button();
            this.btnIsConnected = new System.Windows.Forms.Button();
            this.btnReset = new System.Windows.Forms.Button();
            this.tabControl = new System.Windows.Forms.TabControl();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.tabNetwork.SuspendLayout();
            this.tabPhonebook.SuspendLayout();
            this.tabManageSMS.SuspendLayout();
            this.panel2.SuspendLayout();
            this.tabSendSMS.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.tabGeneral.SuspendLayout();
            this.tabControl.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtOutput
            // 
            this.txtOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.txtOutput.Location = new System.Drawing.Point(8, 256);
            this.txtOutput.MaxLength = 0;
            this.txtOutput.Multiline = true;
            this.txtOutput.Name = "txtOutput";
            this.txtOutput.ReadOnly = true;
            this.txtOutput.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOutput.Size = new System.Drawing.Size(512, 184);
            this.txtOutput.TabIndex = 1;
            this.txtOutput.TextChanged += new System.EventHandler(this.txtOutput_TextChanged);
            // 
            // chkEnableLogging
            // 
            this.chkEnableLogging.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.chkEnableLogging.Location = new System.Drawing.Point(8, 448);
            this.chkEnableLogging.Name = "chkEnableLogging";
            this.chkEnableLogging.Size = new System.Drawing.Size(112, 24);
            this.chkEnableLogging.TabIndex = 2;
            this.chkEnableLogging.Text = "Enable logging";
            this.chkEnableLogging.CheckedChanged += new System.EventHandler(this.chkEnableLogging_CheckedChanged);
            // 
            // txtClearOutput
            // 
            this.txtClearOutput.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.txtClearOutput.Location = new System.Drawing.Point(432, 448);
            this.txtClearOutput.Name = "txtClearOutput";
            this.txtClearOutput.Size = new System.Drawing.Size(88, 23);
            this.txtClearOutput.TabIndex = 3;
            this.txtClearOutput.Text = "Clear Output";
            this.txtClearOutput.Click += new System.EventHandler(this.txtClearOutput_Click);
            // 
            // lblNotConnected
            // 
            this.lblNotConnected.Anchor = System.Windows.Forms.AnchorStyles.Bottom;
            this.lblNotConnected.BackColor = System.Drawing.Color.White;
            this.lblNotConnected.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNotConnected.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNotConnected.ForeColor = System.Drawing.Color.Red;
            this.lblNotConnected.Location = new System.Drawing.Point(166, 448);
            this.lblNotConnected.Name = "lblNotConnected";
            this.lblNotConnected.Size = new System.Drawing.Size(196, 23);
            this.lblNotConnected.TabIndex = 28;
            this.lblNotConnected.Text = "NO PHONE CONNECTED";
            this.lblNotConnected.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblNotConnected.UseMnemonic = false;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.Filter = "Bitmaps (*.bmp, *.jpg, *.gif)|*.bmp;*.jpg;*.gif|All files (*.*)|*.*";
            this.openFileDialog1.Title = "Load bitmap";
            // 
            // tabNetwork
            // 
            this.tabNetwork.Controls.Add(this.btnSubscriberNumbers);
            this.tabNetwork.Controls.Add(this.btnListOperators);
            this.tabNetwork.Controls.Add(this.GetOpSelectionMode);
            this.tabNetwork.Controls.Add(this.GetOperator);
            this.tabNetwork.Location = new System.Drawing.Point(4, 22);
            this.tabNetwork.Name = "tabNetwork";
            this.tabNetwork.Padding = new System.Windows.Forms.Padding(3);
            this.tabNetwork.Size = new System.Drawing.Size(504, 214);
            this.tabNetwork.TabIndex = 6;
            this.tabNetwork.Text = "Network";
            this.tabNetwork.UseVisualStyleBackColor = true;
            // 
            // btnSubscriberNumbers
            // 
            this.btnSubscriberNumbers.Location = new System.Drawing.Point(8, 142);
            this.btnSubscriberNumbers.Name = "btnSubscriberNumbers";
            this.btnSubscriberNumbers.Size = new System.Drawing.Size(128, 36);
            this.btnSubscriberNumbers.TabIndex = 3;
            this.btnSubscriberNumbers.Text = "Get subscriber numbers";
            this.btnSubscriberNumbers.Click += new System.EventHandler(this.btnSubscriberNumbers_Click);
            // 
            // btnListOperators
            // 
            this.btnListOperators.Location = new System.Drawing.Point(8, 100);
            this.btnListOperators.Name = "btnListOperators";
            this.btnListOperators.Size = new System.Drawing.Size(128, 36);
            this.btnListOperators.TabIndex = 2;
            this.btnListOperators.Text = "List operators";
            this.btnListOperators.Click += new System.EventHandler(this.btnListOperators_Click);
            // 
            // GetOpSelectionMode
            // 
            this.GetOpSelectionMode.Location = new System.Drawing.Point(8, 58);
            this.GetOpSelectionMode.Name = "GetOpSelectionMode";
            this.GetOpSelectionMode.Size = new System.Drawing.Size(128, 36);
            this.GetOpSelectionMode.TabIndex = 1;
            this.GetOpSelectionMode.Text = "Get operator selection mode";
            this.GetOpSelectionMode.Click += new System.EventHandler(this.GetOpSelectionMode_Click);
            // 
            // GetOperator
            // 
            this.GetOperator.Location = new System.Drawing.Point(8, 16);
            this.GetOperator.Name = "GetOperator";
            this.GetOperator.Size = new System.Drawing.Size(128, 36);
            this.GetOperator.TabIndex = 0;
            this.GetOperator.Text = "Get current operator";
            this.GetOperator.Click += new System.EventHandler(this.GetOperator_Click);
            // 
            // tabPhonebook
            // 
            this.tabPhonebook.Controls.Add(this.btnPbMemStatus);
            this.tabPhonebook.Controls.Add(this.btnPbStorages);
            this.tabPhonebook.Controls.Add(this.label9);
            this.tabPhonebook.Controls.Add(this.txtDelPbIndex);
            this.tabPhonebook.Controls.Add(this.txtPbNumber);
            this.tabPhonebook.Controls.Add(this.txtPbName);
            this.tabPhonebook.Controls.Add(this.label7);
            this.tabPhonebook.Controls.Add(this.label6);
            this.tabPhonebook.Controls.Add(this.btnCreatePbEntry);
            this.tabPhonebook.Controls.Add(this.label5);
            this.tabPhonebook.Controls.Add(this.rbPhonebookPhone);
            this.tabPhonebook.Controls.Add(this.rbPhonebookSIM);
            this.tabPhonebook.Controls.Add(this.btnExportPhonebook);
            this.tabPhonebook.Controls.Add(this.btnImportPhonebook);
            this.tabPhonebook.Controls.Add(this.btnDumpPhonebook);
            this.tabPhonebook.Controls.Add(this.btnDeletePhonebookEntry);
            this.tabPhonebook.Controls.Add(this.btnDeletePhonebook);
            this.tabPhonebook.Location = new System.Drawing.Point(4, 22);
            this.tabPhonebook.Name = "tabPhonebook";
            this.tabPhonebook.Padding = new System.Windows.Forms.Padding(3);
            this.tabPhonebook.Size = new System.Drawing.Size(504, 214);
            this.tabPhonebook.TabIndex = 1;
            this.tabPhonebook.Text = "Manage Phonebook";
            this.tabPhonebook.UseVisualStyleBackColor = true;
            // 
            // btnPbMemStatus
            // 
            this.btnPbMemStatus.Location = new System.Drawing.Point(152, 16);
            this.btnPbMemStatus.Name = "btnPbMemStatus";
            this.btnPbMemStatus.Size = new System.Drawing.Size(128, 32);
            this.btnPbMemStatus.TabIndex = 6;
            this.btnPbMemStatus.Text = "Get memory status";
            this.btnPbMemStatus.Click += new System.EventHandler(this.btnPbMemStatus_Click);
            // 
            // btnPbStorages
            // 
            this.btnPbStorages.Location = new System.Drawing.Point(8, 144);
            this.btnPbStorages.Name = "btnPbStorages";
            this.btnPbStorages.Size = new System.Drawing.Size(128, 36);
            this.btnPbStorages.TabIndex = 5;
            this.btnPbStorages.Text = "Get supported phonebook storages";
            this.btnPbStorages.Click += new System.EventHandler(this.btnPbStorages_Click);
            // 
            // label9
            // 
            this.label9.Location = new System.Drawing.Point(80, 56);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(48, 16);
            this.label9.TabIndex = 2;
            this.label9.Text = "Index:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtDelPbIndex
            // 
            this.txtDelPbIndex.Location = new System.Drawing.Point(80, 72);
            this.txtDelPbIndex.Name = "txtDelPbIndex";
            this.txtDelPbIndex.Size = new System.Drawing.Size(56, 21);
            this.txtDelPbIndex.TabIndex = 3;
            this.txtDelPbIndex.Text = "1";
            // 
            // txtPbNumber
            // 
            this.txtPbNumber.Location = new System.Drawing.Point(368, 40);
            this.txtPbNumber.Name = "txtPbNumber";
            this.txtPbNumber.Size = new System.Drawing.Size(128, 21);
            this.txtPbNumber.TabIndex = 12;
            this.txtPbNumber.Text = "+483341234567";
            // 
            // txtPbName
            // 
            this.txtPbName.Location = new System.Drawing.Point(368, 16);
            this.txtPbName.Name = "txtPbName";
            this.txtPbName.Size = new System.Drawing.Size(128, 21);
            this.txtPbName.TabIndex = 10;
            this.txtPbName.Text = "Test dummy";
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(304, 16);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 24);
            this.label7.TabIndex = 9;
            this.label7.Text = "Name:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(304, 40);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 24);
            this.label6.TabIndex = 11;
            this.label6.Text = "Number:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // btnCreatePbEntry
            // 
            this.btnCreatePbEntry.Location = new System.Drawing.Point(328, 72);
            this.btnCreatePbEntry.Name = "btnCreatePbEntry";
            this.btnCreatePbEntry.Size = new System.Drawing.Size(128, 32);
            this.btnCreatePbEntry.TabIndex = 13;
            this.btnCreatePbEntry.Text = "Create new entry";
            this.btnCreatePbEntry.Click += new System.EventHandler(this.btnCreatePbEntry_Click);
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(432, 128);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(64, 32);
            this.label5.TabIndex = 20;
            this.label5.Text = "Phonebook storage";
            this.label5.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // rbPhonebookPhone
            // 
            this.rbPhonebookPhone.Location = new System.Drawing.Point(432, 184);
            this.rbPhonebookPhone.Name = "rbPhonebookPhone";
            this.rbPhonebookPhone.Size = new System.Drawing.Size(64, 24);
            this.rbPhonebookPhone.TabIndex = 22;
            this.rbPhonebookPhone.Text = "Phone";
            // 
            // rbPhonebookSIM
            // 
            this.rbPhonebookSIM.Checked = true;
            this.rbPhonebookSIM.Location = new System.Drawing.Point(432, 160);
            this.rbPhonebookSIM.Name = "rbPhonebookSIM";
            this.rbPhonebookSIM.Size = new System.Drawing.Size(64, 24);
            this.rbPhonebookSIM.TabIndex = 21;
            this.rbPhonebookSIM.TabStop = true;
            this.rbPhonebookSIM.Text = "SIM";
            // 
            // btnExportPhonebook
            // 
            this.btnExportPhonebook.Location = new System.Drawing.Point(152, 56);
            this.btnExportPhonebook.Name = "btnExportPhonebook";
            this.btnExportPhonebook.Size = new System.Drawing.Size(128, 32);
            this.btnExportPhonebook.TabIndex = 7;
            this.btnExportPhonebook.Text = "Export phonebook";
            this.btnExportPhonebook.Click += new System.EventHandler(this.btnExportPhonebook_Click);
            // 
            // btnImportPhonebook
            // 
            this.btnImportPhonebook.Location = new System.Drawing.Point(152, 96);
            this.btnImportPhonebook.Name = "btnImportPhonebook";
            this.btnImportPhonebook.Size = new System.Drawing.Size(128, 32);
            this.btnImportPhonebook.TabIndex = 8;
            this.btnImportPhonebook.Text = "Import phonebook";
            this.btnImportPhonebook.Click += new System.EventHandler(this.btnImportPhonebook_Click);
            // 
            // btnDumpPhonebook
            // 
            this.btnDumpPhonebook.Location = new System.Drawing.Point(8, 16);
            this.btnDumpPhonebook.Name = "btnDumpPhonebook";
            this.btnDumpPhonebook.Size = new System.Drawing.Size(128, 32);
            this.btnDumpPhonebook.TabIndex = 0;
            this.btnDumpPhonebook.Text = "Read phonebook";
            this.btnDumpPhonebook.Click += new System.EventHandler(this.btnDumpPhonebook_Click);
            // 
            // btnDeletePhonebookEntry
            // 
            this.btnDeletePhonebookEntry.Location = new System.Drawing.Point(8, 56);
            this.btnDeletePhonebookEntry.Name = "btnDeletePhonebookEntry";
            this.btnDeletePhonebookEntry.Size = new System.Drawing.Size(64, 36);
            this.btnDeletePhonebookEntry.TabIndex = 1;
            this.btnDeletePhonebookEntry.Text = "Delete entry";
            this.btnDeletePhonebookEntry.Click += new System.EventHandler(this.btnDeletePhonebookEntry_Click);
            // 
            // btnDeletePhonebook
            // 
            this.btnDeletePhonebook.Location = new System.Drawing.Point(8, 104);
            this.btnDeletePhonebook.Name = "btnDeletePhonebook";
            this.btnDeletePhonebook.Size = new System.Drawing.Size(128, 32);
            this.btnDeletePhonebook.TabIndex = 4;
            this.btnDeletePhonebook.Text = "Delete all entries";
            this.btnDeletePhonebook.Click += new System.EventHandler(this.btnDeletePhonebook_Click);
            // 
            // tabManageSMS
            // 
            this.tabManageSMS.Controls.Add(this.panel2);
            this.tabManageSMS.Controls.Add(this.label20);
            this.tabManageSMS.Controls.Add(this.txtNewSMSCType);
            this.tabManageSMS.Controls.Add(this.txtNewSMSC);
            this.tabManageSMS.Controls.Add(this.txtDelMsgIndex);
            this.tabManageSMS.Controls.Add(this.chkNewSMSCType);
            this.tabManageSMS.Controls.Add(this.btnGetSMSC);
            this.tabManageSMS.Controls.Add(this.btnSetSMSC);
            this.tabManageSMS.Controls.Add(this.btnMsgMemStatus);
            this.tabManageSMS.Controls.Add(this.label8);
            this.tabManageSMS.Controls.Add(this.label4);
            this.tabManageSMS.Controls.Add(this.btnReadMessages);
            this.tabManageSMS.Controls.Add(this.btnDelMessage);
            this.tabManageSMS.Controls.Add(this.btnDelAllMsgs);
            this.tabManageSMS.Controls.Add(this.btnMsgStorages);
            this.tabManageSMS.Controls.Add(this.btnMsgNotification);
            this.tabManageSMS.Controls.Add(this.btnMsgNotificationOff);
            this.tabManageSMS.Controls.Add(this.btnMsgRoutingOn);
            this.tabManageSMS.Controls.Add(this.btnMsgRoutingOff);
            this.tabManageSMS.Controls.Add(this.btnCopyMessages);
            this.tabManageSMS.Controls.Add(this.btnExportMessages);
            this.tabManageSMS.Controls.Add(this.btnImportMessages);
            this.tabManageSMS.Controls.Add(this.rbMessagePhone);
            this.tabManageSMS.Controls.Add(this.rbMessageSIM);
            this.tabManageSMS.Location = new System.Drawing.Point(4, 22);
            this.tabManageSMS.Name = "tabManageSMS";
            this.tabManageSMS.Padding = new System.Windows.Forms.Padding(3);
            this.tabManageSMS.Size = new System.Drawing.Size(504, 214);
            this.tabManageSMS.TabIndex = 0;
            this.tabManageSMS.Text = "Manage SMS";
            this.tabManageSMS.UseVisualStyleBackColor = true;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.rbExportBinary);
            this.panel2.Controls.Add(this.rbExportText);
            this.panel2.Location = new System.Drawing.Point(430, 11);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(68, 45);
            this.panel2.TabIndex = 13;
            // 
            // rbExportBinary
            // 
            this.rbExportBinary.Checked = true;
            this.rbExportBinary.Location = new System.Drawing.Point(3, 3);
            this.rbExportBinary.Name = "rbExportBinary";
            this.rbExportBinary.Size = new System.Drawing.Size(60, 18);
            this.rbExportBinary.TabIndex = 0;
            this.rbExportBinary.TabStop = true;
            this.rbExportBinary.Text = "Binary";
            // 
            // rbExportText
            // 
            this.rbExportText.Location = new System.Drawing.Point(3, 23);
            this.rbExportText.Name = "rbExportText";
            this.rbExportText.Size = new System.Drawing.Size(60, 18);
            this.rbExportText.TabIndex = 1;
            this.rbExportText.Text = "Text";
            // 
            // label20
            // 
            this.label20.Location = new System.Drawing.Point(429, 64);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(64, 16);
            this.label20.TabIndex = 23;
            this.label20.Text = "Binary only";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtNewSMSCType
            // 
            this.txtNewSMSCType.Location = new System.Drawing.Point(368, 192);
            this.txtNewSMSCType.Name = "txtNewSMSCType";
            this.txtNewSMSCType.Size = new System.Drawing.Size(48, 21);
            this.txtNewSMSCType.TabIndex = 19;
            this.txtNewSMSCType.Text = "145";
            // 
            // txtNewSMSC
            // 
            this.txtNewSMSC.Location = new System.Drawing.Point(296, 168);
            this.txtNewSMSC.Name = "txtNewSMSC";
            this.txtNewSMSC.Size = new System.Drawing.Size(128, 21);
            this.txtNewSMSC.TabIndex = 17;
            this.txtNewSMSC.Text = "+483340815";
            // 
            // txtDelMsgIndex
            // 
            this.txtDelMsgIndex.Location = new System.Drawing.Point(80, 72);
            this.txtDelMsgIndex.Name = "txtDelMsgIndex";
            this.txtDelMsgIndex.Size = new System.Drawing.Size(56, 21);
            this.txtDelMsgIndex.TabIndex = 3;
            this.txtDelMsgIndex.Text = "1";
            // 
            // chkNewSMSCType
            // 
            this.chkNewSMSCType.Location = new System.Drawing.Point(296, 192);
            this.chkNewSMSCType.Name = "chkNewSMSCType";
            this.chkNewSMSCType.Size = new System.Drawing.Size(64, 24);
            this.chkNewSMSCType.TabIndex = 18;
            this.chkNewSMSCType.Text = "Type:";
            // 
            // btnGetSMSC
            // 
            this.btnGetSMSC.Location = new System.Drawing.Point(296, 96);
            this.btnGetSMSC.Name = "btnGetSMSC";
            this.btnGetSMSC.Size = new System.Drawing.Size(128, 32);
            this.btnGetSMSC.TabIndex = 15;
            this.btnGetSMSC.Text = "Get SMSC Address";
            this.btnGetSMSC.Click += new System.EventHandler(this.btnGetSMSC_Click);
            // 
            // btnSetSMSC
            // 
            this.btnSetSMSC.Location = new System.Drawing.Point(296, 136);
            this.btnSetSMSC.Name = "btnSetSMSC";
            this.btnSetSMSC.Size = new System.Drawing.Size(128, 32);
            this.btnSetSMSC.TabIndex = 16;
            this.btnSetSMSC.Text = "Set SMSC Address";
            this.btnSetSMSC.Click += new System.EventHandler(this.btnSetSMSC_Click);
            // 
            // btnMsgMemStatus
            // 
            this.btnMsgMemStatus.Location = new System.Drawing.Point(152, 128);
            this.btnMsgMemStatus.Name = "btnMsgMemStatus";
            this.btnMsgMemStatus.Size = new System.Drawing.Size(128, 32);
            this.btnMsgMemStatus.TabIndex = 10;
            this.btnMsgMemStatus.Text = "Get memory status";
            this.btnMsgMemStatus.Click += new System.EventHandler(this.btnMsgMemStatus_Click);
            // 
            // label8
            // 
            this.label8.Location = new System.Drawing.Point(80, 56);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 16);
            this.label8.TabIndex = 2;
            this.label8.Text = "Index:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(432, 128);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(64, 32);
            this.label4.TabIndex = 20;
            this.label4.Text = "Message storage";
            this.label4.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
            // 
            // btnReadMessages
            // 
            this.btnReadMessages.Location = new System.Drawing.Point(8, 16);
            this.btnReadMessages.Name = "btnReadMessages";
            this.btnReadMessages.Size = new System.Drawing.Size(128, 32);
            this.btnReadMessages.TabIndex = 0;
            this.btnReadMessages.Text = "Read all messages";
            this.btnReadMessages.Click += new System.EventHandler(this.btnReadMessages_Click);
            // 
            // btnDelMessage
            // 
            this.btnDelMessage.Location = new System.Drawing.Point(8, 56);
            this.btnDelMessage.Name = "btnDelMessage";
            this.btnDelMessage.Size = new System.Drawing.Size(64, 36);
            this.btnDelMessage.TabIndex = 1;
            this.btnDelMessage.Text = "Delete Message";
            this.btnDelMessage.Click += new System.EventHandler(this.btnDelMessage_Click);
            // 
            // btnDelAllMsgs
            // 
            this.btnDelAllMsgs.Location = new System.Drawing.Point(8, 104);
            this.btnDelAllMsgs.Name = "btnDelAllMsgs";
            this.btnDelAllMsgs.Size = new System.Drawing.Size(128, 32);
            this.btnDelAllMsgs.TabIndex = 4;
            this.btnDelAllMsgs.Text = "Delete all messages";
            this.btnDelAllMsgs.Click += new System.EventHandler(this.btnDelAllMsgs_Click);
            // 
            // btnMsgStorages
            // 
            this.btnMsgStorages.Location = new System.Drawing.Point(8, 144);
            this.btnMsgStorages.Name = "btnMsgStorages";
            this.btnMsgStorages.Size = new System.Drawing.Size(128, 36);
            this.btnMsgStorages.TabIndex = 5;
            this.btnMsgStorages.Text = "Get supported message storages";
            this.btnMsgStorages.Click += new System.EventHandler(this.btnMsgStorages_Click);
            // 
            // btnMsgNotification
            // 
            this.btnMsgNotification.Location = new System.Drawing.Point(152, 72);
            this.btnMsgNotification.Name = "btnMsgNotification";
            this.btnMsgNotification.Size = new System.Drawing.Size(72, 48);
            this.btnMsgNotification.TabIndex = 8;
            this.btnMsgNotification.Text = "Enable message notifications";
            this.btnMsgNotification.Click += new System.EventHandler(this.btnMsgNotification_Click);
            // 
            // btnMsgNotificationOff
            // 
            this.btnMsgNotificationOff.Location = new System.Drawing.Point(224, 72);
            this.btnMsgNotificationOff.Name = "btnMsgNotificationOff";
            this.btnMsgNotificationOff.Size = new System.Drawing.Size(56, 48);
            this.btnMsgNotificationOff.TabIndex = 9;
            this.btnMsgNotificationOff.Text = "Disable";
            this.btnMsgNotificationOff.Click += new System.EventHandler(this.btnMsgNotificationOff_Click);
            // 
            // btnMsgRoutingOn
            // 
            this.btnMsgRoutingOn.Location = new System.Drawing.Point(152, 16);
            this.btnMsgRoutingOn.Name = "btnMsgRoutingOn";
            this.btnMsgRoutingOn.Size = new System.Drawing.Size(72, 48);
            this.btnMsgRoutingOn.TabIndex = 6;
            this.btnMsgRoutingOn.Text = "Enable message routing";
            this.btnMsgRoutingOn.Click += new System.EventHandler(this.btnMsgRoutingOn_Click);
            // 
            // btnMsgRoutingOff
            // 
            this.btnMsgRoutingOff.Location = new System.Drawing.Point(224, 16);
            this.btnMsgRoutingOff.Name = "btnMsgRoutingOff";
            this.btnMsgRoutingOff.Size = new System.Drawing.Size(56, 48);
            this.btnMsgRoutingOff.TabIndex = 7;
            this.btnMsgRoutingOff.Text = "Disable";
            this.btnMsgRoutingOff.Click += new System.EventHandler(this.btnMsgRoutingOff_Click);
            // 
            // btnCopyMessages
            // 
            this.btnCopyMessages.Location = new System.Drawing.Point(152, 168);
            this.btnCopyMessages.Name = "btnCopyMessages";
            this.btnCopyMessages.Size = new System.Drawing.Size(128, 36);
            this.btnCopyMessages.TabIndex = 11;
            this.btnCopyMessages.Text = "Copy all messages from SIM to phone";
            this.btnCopyMessages.Click += new System.EventHandler(this.btnCopyMessages_Click);
            // 
            // btnExportMessages
            // 
            this.btnExportMessages.Location = new System.Drawing.Point(296, 16);
            this.btnExportMessages.Name = "btnExportMessages";
            this.btnExportMessages.Size = new System.Drawing.Size(128, 32);
            this.btnExportMessages.TabIndex = 12;
            this.btnExportMessages.Text = "Export all messages";
            this.btnExportMessages.Click += new System.EventHandler(this.btnExportMessages_Click);
            // 
            // btnImportMessages
            // 
            this.btnImportMessages.Location = new System.Drawing.Point(296, 56);
            this.btnImportMessages.Name = "btnImportMessages";
            this.btnImportMessages.Size = new System.Drawing.Size(128, 32);
            this.btnImportMessages.TabIndex = 14;
            this.btnImportMessages.Text = "Import messages";
            this.btnImportMessages.Click += new System.EventHandler(this.btnImportMessages_Click);
            // 
            // rbMessagePhone
            // 
            this.rbMessagePhone.Location = new System.Drawing.Point(432, 184);
            this.rbMessagePhone.Name = "rbMessagePhone";
            this.rbMessagePhone.Size = new System.Drawing.Size(64, 24);
            this.rbMessagePhone.TabIndex = 22;
            this.rbMessagePhone.Text = "Phone";
            // 
            // rbMessageSIM
            // 
            this.rbMessageSIM.Checked = true;
            this.rbMessageSIM.Location = new System.Drawing.Point(432, 160);
            this.rbMessageSIM.Name = "rbMessageSIM";
            this.rbMessageSIM.Size = new System.Drawing.Size(64, 24);
            this.rbMessageSIM.TabIndex = 21;
            this.rbMessageSIM.TabStop = true;
            this.rbMessageSIM.Text = "SIM";
            // 
            // tabSendSMS
            // 
            this.tabSendSMS.Controls.Add(this.groupBox1);
            this.tabSendSMS.Controls.Add(this.btnSendMessage);
            this.tabSendSMS.Controls.Add(this.txtNumber);
            this.tabSendSMS.Controls.Add(this.txtMessage);
            this.tabSendSMS.Controls.Add(this.label2);
            this.tabSendSMS.Controls.Add(this.label1);
            this.tabSendSMS.Location = new System.Drawing.Point(4, 22);
            this.tabSendSMS.Name = "tabSendSMS";
            this.tabSendSMS.Padding = new System.Windows.Forms.Padding(3);
            this.tabSendSMS.Size = new System.Drawing.Size(504, 214);
            this.tabSendSMS.TabIndex = 4;
            this.tabSendSMS.Text = "Send SMS";
            this.tabSendSMS.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txtDestinationPort);
            this.groupBox1.Controls.Add(this.chkDestinationPort);
            this.groupBox1.Controls.Add(this.chkSmsBatchMode);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.txtSendTimes);
            this.groupBox1.Controls.Add(this.chkMultipleTimes);
            this.groupBox1.Controls.Add(this.chkSMSC);
            this.groupBox1.Controls.Add(this.chkUnicode);
            this.groupBox1.Controls.Add(this.chkReport);
            this.groupBox1.Controls.Add(this.chkAlert);
            this.groupBox1.Controls.Add(this.txtSMSC);
            this.groupBox1.Location = new System.Drawing.Point(8, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(488, 120);
            this.groupBox1.TabIndex = 16;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Options";
            // 
            // txtDestinationPort
            // 
            this.txtDestinationPort.Location = new System.Drawing.Point(348, 66);
            this.txtDestinationPort.Name = "txtDestinationPort";
            this.txtDestinationPort.Size = new System.Drawing.Size(48, 21);
            this.txtDestinationPort.TabIndex = 10;
            this.txtDestinationPort.Text = "0";
            // 
            // chkDestinationPort
            // 
            this.chkDestinationPort.Location = new System.Drawing.Point(232, 64);
            this.chkDestinationPort.Name = "chkDestinationPort";
            this.chkDestinationPort.Size = new System.Drawing.Size(110, 24);
            this.chkDestinationPort.TabIndex = 9;
            this.chkDestinationPort.Text = "Destination port:";
            this.chkDestinationPort.UseVisualStyleBackColor = true;
            // 
            // chkSmsBatchMode
            // 
            this.chkSmsBatchMode.Location = new System.Drawing.Point(232, 40);
            this.chkSmsBatchMode.Name = "chkSmsBatchMode";
            this.chkSmsBatchMode.Size = new System.Drawing.Size(232, 24);
            this.chkSmsBatchMode.TabIndex = 8;
            this.chkSmsBatchMode.Text = "Enable SMS batch mode";
            this.chkSmsBatchMode.UseVisualStyleBackColor = true;
            this.chkSmsBatchMode.CheckedChanged += new System.EventHandler(this.chkSmsBatchMode_CheckedChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(402, 19);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(38, 15);
            this.label19.TabIndex = 7;
            this.label19.Text = "times";
            // 
            // txtSendTimes
            // 
            this.txtSendTimes.Location = new System.Drawing.Point(348, 18);
            this.txtSendTimes.Name = "txtSendTimes";
            this.txtSendTimes.Size = new System.Drawing.Size(48, 21);
            this.txtSendTimes.TabIndex = 6;
            this.txtSendTimes.Text = "1";
            // 
            // chkMultipleTimes
            // 
            this.chkMultipleTimes.Location = new System.Drawing.Point(232, 16);
            this.chkMultipleTimes.Name = "chkMultipleTimes";
            this.chkMultipleTimes.Size = new System.Drawing.Size(104, 24);
            this.chkMultipleTimes.TabIndex = 5;
            this.chkMultipleTimes.Text = "Send message";
            this.chkMultipleTimes.UseVisualStyleBackColor = true;
            // 
            // chkSMSC
            // 
            this.chkSMSC.Location = new System.Drawing.Point(8, 16);
            this.chkSMSC.Name = "chkSMSC";
            this.chkSMSC.Size = new System.Drawing.Size(64, 24);
            this.chkSMSC.TabIndex = 0;
            this.chkSMSC.Text = "SMSC:";
            this.chkSMSC.CheckedChanged += new System.EventHandler(this.chkSMSC_CheckedChanged);
            // 
            // chkUnicode
            // 
            this.chkUnicode.Location = new System.Drawing.Point(8, 88);
            this.chkUnicode.Name = "chkUnicode";
            this.chkUnicode.Size = new System.Drawing.Size(208, 24);
            this.chkUnicode.TabIndex = 4;
            this.chkUnicode.Text = "Send as Unicode (UCS2)";
            // 
            // chkReport
            // 
            this.chkReport.Location = new System.Drawing.Point(8, 64);
            this.chkReport.Name = "chkReport";
            this.chkReport.Size = new System.Drawing.Size(208, 24);
            this.chkReport.TabIndex = 3;
            this.chkReport.Text = "Request status report";
            // 
            // chkAlert
            // 
            this.chkAlert.Location = new System.Drawing.Point(8, 40);
            this.chkAlert.Name = "chkAlert";
            this.chkAlert.Size = new System.Drawing.Size(208, 24);
            this.chkAlert.TabIndex = 2;
            this.chkAlert.Text = "Request immediate display (alert)";
            // 
            // txtSMSC
            // 
            this.txtSMSC.Enabled = false;
            this.txtSMSC.Location = new System.Drawing.Point(72, 16);
            this.txtSMSC.Name = "txtSMSC";
            this.txtSMSC.Size = new System.Drawing.Size(128, 21);
            this.txtSMSC.TabIndex = 1;
            // 
            // btnSendMessage
            // 
            this.btnSendMessage.Location = new System.Drawing.Point(216, 48);
            this.btnSendMessage.Name = "btnSendMessage";
            this.btnSendMessage.Size = new System.Drawing.Size(128, 32);
            this.btnSendMessage.TabIndex = 15;
            this.btnSendMessage.Text = "Send Message";
            this.btnSendMessage.Click += new System.EventHandler(this.btnSendMessage_Click);
            // 
            // txtNumber
            // 
            this.txtNumber.Location = new System.Drawing.Point(72, 48);
            this.txtNumber.MaxLength = 30;
            this.txtNumber.Name = "txtNumber";
            this.txtNumber.Size = new System.Drawing.Size(128, 21);
            this.txtNumber.TabIndex = 3;
            this.txtNumber.Text = "+841278252934";
            // 
            // txtMessage
            // 
            this.txtMessage.Location = new System.Drawing.Point(72, 16);
            this.txtMessage.MaxLength = 160;
            this.txtMessage.Name = "txtMessage";
            this.txtMessage.Size = new System.Drawing.Size(256, 21);
            this.txtMessage.TabIndex = 1;
            this.txtMessage.Text = "This is a test!";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(8, 48);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 23);
            this.label2.TabIndex = 2;
            this.label2.Text = "Number:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // label1
            // 
            this.label1.Location = new System.Drawing.Point(8, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Message:";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // tabGeneral
            // 
            this.tabGeneral.Controls.Add(this.txtPin);
            this.tabGeneral.Controls.Add(this.btnEnterPin);
            this.tabGeneral.Controls.Add(this.btnGetPinStatus);
            this.tabGeneral.Controls.Add(this.btnBatteryCharge);
            this.tabGeneral.Controls.Add(this.btnSignalQuality);
            this.tabGeneral.Controls.Add(this.btnIdentify);
            this.tabGeneral.Controls.Add(this.btnIsConnected);
            this.tabGeneral.Controls.Add(this.btnReset);
            this.tabGeneral.Location = new System.Drawing.Point(4, 24);
            this.tabGeneral.Name = "tabGeneral";
            this.tabGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.tabGeneral.Size = new System.Drawing.Size(504, 212);
            this.tabGeneral.TabIndex = 2;
            this.tabGeneral.Text = "General";
            this.tabGeneral.UseVisualStyleBackColor = true;
            // 
            // txtPin
            // 
            this.txtPin.Location = new System.Drawing.Point(212, 63);
            this.txtPin.Name = "txtPin";
            this.txtPin.Size = new System.Drawing.Size(58, 21);
            this.txtPin.TabIndex = 7;
            this.txtPin.UseSystemPasswordChar = true;
            // 
            // btnEnterPin
            // 
            this.btnEnterPin.Location = new System.Drawing.Point(142, 56);
            this.btnEnterPin.Name = "btnEnterPin";
            this.btnEnterPin.Size = new System.Drawing.Size(64, 32);
            this.btnEnterPin.TabIndex = 6;
            this.btnEnterPin.Text = "Enter PIN";
            this.btnEnterPin.Click += new System.EventHandler(this.btnEnterPin_Click);
            // 
            // btnGetPinStatus
            // 
            this.btnGetPinStatus.Location = new System.Drawing.Point(142, 16);
            this.btnGetPinStatus.Name = "btnGetPinStatus";
            this.btnGetPinStatus.Size = new System.Drawing.Size(128, 32);
            this.btnGetPinStatus.TabIndex = 5;
            this.btnGetPinStatus.Text = "Get PIN status";
            this.btnGetPinStatus.Click += new System.EventHandler(this.btnGetPinStatus_Click);
            // 
            // btnBatteryCharge
            // 
            this.btnBatteryCharge.Location = new System.Drawing.Point(8, 176);
            this.btnBatteryCharge.Name = "btnBatteryCharge";
            this.btnBatteryCharge.Size = new System.Drawing.Size(128, 32);
            this.btnBatteryCharge.TabIndex = 4;
            this.btnBatteryCharge.Text = "Get battery charge";
            this.btnBatteryCharge.Click += new System.EventHandler(this.btnBatteryCharge_Click);
            // 
            // btnSignalQuality
            // 
            this.btnSignalQuality.Location = new System.Drawing.Point(8, 136);
            this.btnSignalQuality.Name = "btnSignalQuality";
            this.btnSignalQuality.Size = new System.Drawing.Size(128, 32);
            this.btnSignalQuality.TabIndex = 3;
            this.btnSignalQuality.Text = "Get signal quality";
            this.btnSignalQuality.Click += new System.EventHandler(this.btnSignalQuality_Click);
            // 
            // btnIdentify
            // 
            this.btnIdentify.Location = new System.Drawing.Point(8, 56);
            this.btnIdentify.Name = "btnIdentify";
            this.btnIdentify.Size = new System.Drawing.Size(128, 32);
            this.btnIdentify.TabIndex = 1;
            this.btnIdentify.Text = "Identify phone";
            this.btnIdentify.Click += new System.EventHandler(this.btnIdentify_Click);
            // 
            // btnIsConnected
            // 
            this.btnIsConnected.Location = new System.Drawing.Point(8, 16);
            this.btnIsConnected.Name = "btnIsConnected";
            this.btnIsConnected.Size = new System.Drawing.Size(128, 32);
            this.btnIsConnected.TabIndex = 0;
            this.btnIsConnected.Text = "Is connected?";
            this.btnIsConnected.Click += new System.EventHandler(this.btnIsConnected_Click);
            // 
            // btnReset
            // 
            this.btnReset.Location = new System.Drawing.Point(8, 96);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(179, 32);
            this.btnReset.TabIndex = 2;
            this.btnReset.Text = "Reset to default config";
            this.btnReset.Click += new System.EventHandler(this.btnReset_Click);
            // 
            // tabControl
            // 
            this.tabControl.Controls.Add(this.tabGeneral);
            this.tabControl.Controls.Add(this.tabSendSMS);
            this.tabControl.Controls.Add(this.tabManageSMS);
            this.tabControl.Controls.Add(this.tabPhonebook);
            this.tabControl.Controls.Add(this.tabNetwork);
            this.tabControl.Location = new System.Drawing.Point(8, 8);
            this.tabControl.Name = "tabControl";
            this.tabControl.SelectedIndex = 0;
            this.tabControl.Size = new System.Drawing.Size(512, 240);
            this.tabControl.TabIndex = 0;
            // 
            // timer1
            // 
            this.timer1.Interval = 5000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmDemo
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
            this.ClientSize = new System.Drawing.Size(528, 478);
            this.Controls.Add(this.lblNotConnected);
            this.Controls.Add(this.txtClearOutput);
            this.Controls.Add(this.tabControl);
            this.Controls.Add(this.chkEnableLogging);
            this.Controls.Add(this.txtOutput);
            this.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Name = "frmDemo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GSMComm Demo 209";
            this.Load += new System.EventHandler(this.frmDemo_Load);
            this.Closing += new System.ComponentModel.CancelEventHandler(this.frmDemo_Closing);
            this.tabNetwork.ResumeLayout(false);
            this.tabPhonebook.ResumeLayout(false);
            this.tabPhonebook.PerformLayout();
            this.tabManageSMS.ResumeLayout(false);
            this.tabManageSMS.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.tabSendSMS.ResumeLayout(false);
            this.tabSendSMS.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.tabGeneral.ResumeLayout(false);
            this.tabGeneral.PerformLayout();
            this.tabControl.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.DoEvents();
            Application.Run(new frmDemo());
        }

        private void frmDemo_Load(object sender, System.EventArgs e)
        {
            // Prompt user for connection settings
            string portName = GsmCommMain.DefaultPortName;
            int baudRate = GsmCommMain.DefaultBaudRate;
            int timeout = GsmCommMain.DefaultTimeout;
            frmConnection dlg = new frmConnection();
            dlg.StartPosition = FormStartPosition.CenterScreen;
            dlg.SetData(portName, baudRate, timeout);
            if (dlg.ShowDialog(this) == DialogResult.OK)
                dlg.GetData(out portName, out baudRate, out timeout);
            else
            {
                Close();
                return;
            }

            Cursor.Current = Cursors.WaitCursor;
            comm = new GsmCommMain(portName, baudRate, timeout);
            Cursor.Current = Cursors.Default;
            comm.PhoneConnected += new EventHandler(comm_PhoneConnected);
            comm.PhoneDisconnected += new EventHandler(comm_PhoneDisconnected);

            bool retry;
            do
            {
                retry = false;
                try
                {
                    Cursor.Current = Cursors.WaitCursor;
                    comm.Open();
                    Cursor.Current = Cursors.Default;
                    timer1.Enabled = true;
                    //      MessageBox.Show("Thuc hien thanh cong");
                }
                catch (Exception)
                {
                    Cursor.Current = Cursors.Default;
                    if (MessageBox.Show(this, "Unable to open the port.", "Error",
                        MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning) == DialogResult.Retry)
                        retry = true;
                    else
                    {
                        Close();
                        return;
                    }
                }
            }
            while (retry);

            // Add custom commands
            ProtocolCommand[] commands = new ProtocolCommand[]
			{
				new ProtocolCommand("Send", true, false, false), // NeedsData
				new ProtocolCommand("Receive", false, false, false),
				new ProtocolCommand("ExecCommand", true, false, false), // NeedsData
				new ProtocolCommand("ExecCommand2", true, false, true), // NeedsData, NeedsError
				new ProtocolCommand("ExecAndReceiveMultiple", true, false, false), // NeedsData
				new ProtocolCommand("ExecAndReceiveAnything", true, true, false), // NeedsData, NeedsPattern
				new ProtocolCommand("ReceiveMultiple", false, false, false),
				new ProtocolCommand("ReceiveAnyhing", false, true, false) // NeedsPattern
			};
            //timer1.Enabled = true;
            //timer1.Start();

        }

        private void frmDemo_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Kill SMS server if running


            // Clean up comm object
            if (comm != null)
            {
                // Unregister events
                if (chkEnableLogging.Checked)
                {
                    comm.LoglineAdded -= new LoglineAddedEventHandler(comm_LoglineAdded);
                    chkEnableLogging.Checked = false;
                }
                comm.PhoneConnected -= new EventHandler(comm_PhoneConnected);
                comm.PhoneDisconnected -= new EventHandler(comm_PhoneDisconnected);
                if (registerMessageReceived)
                {
                    comm.MessageReceived -= new MessageReceivedEventHandler(comm_MessageReceived);
                    registerMessageReceived = false;
                }

                // Close connection to phone
                if (comm != null && comm.IsOpen())
                    comm.Close();

                comm = null;
            }
        }

        private void Output(string text)
        {
            if (this.txtOutput.InvokeRequired)
            {
                SetTextCallback stc = new SetTextCallback(Output);
                this.Invoke(stc, new object[] { text });
            }
            else
            {
                txtOutput.AppendText(text);
                txtOutput.AppendText("\r\n");
            }
        }

        private void Output(string text, params object[] args)
        {
            string msg = string.Format(text, args);
            Output(msg);
        }

        private void ShowException(Exception ex)
        {
            Output("Error: " + ex.Message + " (" + ex.GetType().ToString() + ")");
            Output("");
        }

        private void ShowException(Exception ex, string messagePrefix)
        {
            Output(messagePrefix + " " + ex.Message + " (" + ex.GetType().ToString() + ")");
            Output("");
        }

        private bool Confirmed()
        {
            return (MessageBox.Show(this, "Really?", "Warning", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
                == DialogResult.Yes);
        }

        private string GetMessageStorage()
        {
            string storage = string.Empty;
            if (rbMessageSIM.Checked)
                storage = PhoneStorageType.Sim;
            if (rbMessagePhone.Checked)
                storage = PhoneStorageType.Phone;

            if (storage.Length == 0)
                throw new ApplicationException("Unknown message storage.");
            else
                return storage;
        }

        private string GetPhonebookStorage()
        {
            string storage = string.Empty;
            if (rbPhonebookSIM.Checked)
                storage = PhoneStorageType.Sim;
            if (rbPhonebookPhone.Checked)
                storage = PhoneStorageType.Phone;

            if (storage.Length == 0)
                throw new ApplicationException("Unknown phonebook storage.");
            else
                return storage;
        }

        #region General
        private void btnIdentify_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                IdentificationInfo info = comm.IdentifyDevice();
                Output("Manufacturer: " + info.Manufacturer);
                Output("Model: " + info.Model);
                Output("Revision: " + info.Revision);
                Output("Serial number: " + info.SerialNumber);
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnReset_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Reset to default configuration
                comm.ResetToDefaultConfig();
                Output("Config reset");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnIsConnected_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                if (!comm.IsConnected())
                    Output("Phone is NOT connected.");
                else
                    Output("Phone is connected.");

                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnSignalQuality_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get signal quality
                SignalQualityInfo info = comm.GetSignalQuality();
                Output("Signal strength: " + info.SignalStrength.ToString());
                Output("Bit error rate: " + info.BitErrorRate.ToString());
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnBatteryCharge_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get battery charge
                BatteryChargeInfo info = comm.GetBatteryCharge();
                Output("Battery charging status: " + info.BatteryChargingStatus.ToString());
                Output("Battery charge level: " + info.BatteryChargeLevel.ToString());
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnGetPinStatus_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get PIN status
                PinStatus status = comm.GetPinStatus();
                Output("PIN status: " + status.ToString());
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnEnterPin_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Enter PIN
                comm.EnterPin(txtPin.Text);
                Output("PIN entry OK.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion

        #region Send SMS

        private void chkSMSC_CheckedChanged(object sender, System.EventArgs e)
        {
            txtSMSC.Enabled = chkSMSC.Checked;
            if (chkSMSC.Checked && txtSMSC.Text.Length == 0)
                txtSMSC.Focus();
        }

        private void chkSmsBatchMode_CheckedChanged(object sender, System.EventArgs e)
        {
            if (chkSmsBatchMode.Checked)
                chkMultipleTimes.Checked = true;
        }

        private void btnSendMessage_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Send an SMS message
                SmsSubmitPdu pdu;
                if (!chkUnicode.Checked)
                {
                    // Send message in the default format
                    pdu = new SmsSubmitPdu(txtMessage.Text, txtNumber.Text);
                }
                else
                {
                    // Send message in Unicode format
                    byte dcs = (byte)DataCodingScheme.GeneralCoding.Alpha16Bit;
                    pdu = new SmsSubmitPdu(txtMessage.Text, txtNumber.Text, dcs);
                }

                // Request immediate display (alert)
                if (chkAlert.Checked)
                    pdu.DataCodingScheme |= (byte)DataCodingScheme.GeneralCoding.Class0;

                //// Send message to a destination port
                //if (chkDestinationPort.Checked)
                //{
                //    ushort destinationPort = ushort.Parse(txtDestinationPort.Text);
                //    byte[] userDataHeader = SmartMessageFactory.CreatePortAddressHeader(destinationPort);
                //    pdu.AddUserDataHeader(userDataHeader);
                //}

                //// Use an explicit SMSC if this is set
                //if (chkSMSC.Checked)
                //    pdu.SmscAddress = txtSMSC.Text;

                //// If a status report should be generated, set that here
                //if (chkReport.Checked)
                //    pdu.RequestStatusReport = true;

                // Send the same message multiple times if this is set
                int times = chkMultipleTimes.Checked ? int.Parse(txtSendTimes.Text) : 1;

                // If SMS batch mode should be activated, do it immediately before sending the first message
                if (chkSmsBatchMode.Checked)
                    comm.EnableTemporarySmsBatchMode();

                // Send the message the specified number of times
                for (int i = 0; i < times; i++)
                {
                    comm.SendMessage(pdu);
                    Output("Message {0} of {1} sent.", i + 1, times);
                    Output("");
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }
        #endregion

        #region Manage SMS
        private void btnReadMessages_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetMessageStorage();

            try
            {
                // Read all SMS messages from the storage
                DecodedShortMessage[] messages = comm.ReadMessages(PhoneMessageStatus.All, storage);
                foreach (DecodedShortMessage message in messages)
                {
                    Output(string.Format("Message status = {0}, Location = {1}/{2}",
                        StatusToString(message.Status), message.Storage, message.Index));
                    ShowMessage(message.Data);
                    Output("");
                }
                Output(string.Format("{0,9} messages read.", messages.Length.ToString()));
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnDelMessage_Click(object sender, System.EventArgs e)
        {
            int index;
            try
            {
                index = int.Parse(txtDelMsgIndex.Text);
            }
            catch (Exception ex)
            {
                ShowException(ex);
                return;
            }

            if (!Confirmed()) return;
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetMessageStorage();
            try
            {
                // Delete the message with the specified index from storage
                comm.DeleteMessage(index, storage);
                Output("Message deleted.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnMsgStorages_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get the supported short message storages
                MessageStorageInfo storages = comm.GetMessageStorages();
                Output("Supported read storages: " + MakeArrayString(storages.ReadStorages));
                Output("Supported write storages: " + MakeArrayString(storages.WriteStorages));
                Output("Supported receive storages: " + MakeArrayString(storages.ReceiveStorages));
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnDelAllMsgs_Click(object sender, System.EventArgs e)
        {
            if (!Confirmed()) return;
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetMessageStorage();
            try
            {
                // Delete all messages from phone memory
                comm.DeleteMessages(DeleteScope.All, storage);
                Output("Messages deleted.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnCopyMessages_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                Cursor.Current = Cursors.WaitCursor;

                // Copy all messages from SIM memory to phone memory
                ShortMessageFromPhone[] messages = comm.ReadRawMessages(PhoneMessageStatus.All, PhoneStorageType.Sim);
                Output(messages.Length.ToString() + " messages read.");
                foreach (ShortMessageFromPhone msg in messages)
                {
                    int index = comm.WriteRawMessage(msg, PhoneStorageType.Phone);
                    Output("Message copied from SIM index " + msg.Index.ToString() +
                        " to phone index " + index.ToString() + ".");
                }
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnExportMessages_Click(object sender, System.EventArgs e)
        {
            if (rbExportBinary.Checked)
                ExportMessagesAsBinary();
            else if (rbExportText.Checked)
                ExportMessagesAsText();
            else
                Output("Unknown export method.");
        }

        private void ExportMessagesAsBinary()
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetMessageStorage();
            try
            {
                // Read and serialize all short messages from storage into an XML file.
                ShortMessage[] messages = comm.ReadRawMessages(PhoneMessageStatus.All, storage);
                Output(messages.Length.ToString() + " message(s) read.");

                const string filename = @"C:\messages.xml";
                Output("Exporting the messages to " + filename + "...");
                System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(
                    typeof(ShortMessageFromPhone[]));
                System.IO.StreamWriter sw = System.IO.File.CreateText(filename);
                ser.Serialize(sw, messages);
                sw.Close();
                Output("Done.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void ExportMessagesAsText()
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetMessageStorage();
            try
            {
                // Read and serialize all short messages from storage into an XML file.
                DecodedShortMessage[] messages = comm.ReadMessages(PhoneMessageStatus.All, storage);
                Output(messages.Length.ToString() + " message(s) read.");

                const string filename = @"C:\messages_text.xml";
                Output("Exporting the messages to " + filename + "...");
                System.Xml.XmlTextWriter xmlWriter = new System.Xml.XmlTextWriter(filename, System.Text.Encoding.UTF8);
                // Change default writer settings to produce readable output
                xmlWriter.Formatting = System.Xml.Formatting.Indented;
                xmlWriter.Indentation = 4;

                xmlWriter.WriteStartDocument();
                xmlWriter.WriteStartElement("ShortMessages");
                foreach (DecodedShortMessage message in messages)
                {
                    xmlWriter.WriteStartElement("Message");
                    string sender = string.Empty;
                    string timestamp = string.Empty;
                    string text = message.Data.UserDataText;
                    if (message.Data is SmsDeliverPdu)
                    {
                        SmsDeliverPdu deliver = (SmsDeliverPdu)message.Data;
                        sender = deliver.OriginatingAddress;
                        timestamp = deliver.SCTimestamp.ToSortableString();
                    }
                    xmlWriter.WriteElementString("Sender", sender);
                    xmlWriter.WriteElementString("Timestamp", timestamp);
                    xmlWriter.WriteElementString("Text", text);
                    xmlWriter.WriteEndElement();
                }
                xmlWriter.WriteEndElement();
                xmlWriter.WriteEndDocument();
                xmlWriter.Close();
                Output("Done.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnImportMessages_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetMessageStorage();
            try
            {
                // Load and copy all saved short messages to storage
                const string filename = @"C:\messages.xml";
                Output("Importing messages from " + filename + "...");
                System.IO.StreamReader sr = System.IO.File.OpenText(filename);
                System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(typeof(ShortMessageFromPhone[]));
                object temp = ser.Deserialize(sr);
                sr.Close();
                ShortMessageFromPhone[] messages = (ShortMessageFromPhone[])temp;
                foreach (ShortMessageFromPhone msg in messages)
                {
                    int index = comm.WriteRawMessage(msg, storage);
                    Output("Saved message to storage index " + index.ToString() + ".");
                }
                Output("Done.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnMsgNotification_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Enable notifications about new received messages
                if (!registerMessageReceived)
                {
                    comm.MessageReceived += new MessageReceivedEventHandler(comm_MessageReceived);
                    registerMessageReceived = true;
                }
                comm.EnableMessageNotifications();
                Output("Message notifications activated.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnMsgNotificationOff_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Disable message notifications
                comm.DisableMessageNotifications();
                if (registerMessageReceived)
                {
                    comm.MessageReceived -= new MessageReceivedEventHandler(comm_MessageReceived);
                    registerMessageReceived = false;
                }
                Output("Message notifications deactivated.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnMsgRoutingOn_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Enable direct message routing to the application
                if (!registerMessageReceived)
                {
                    comm.MessageReceived += new MessageReceivedEventHandler(comm_MessageReceived);
                    registerMessageReceived = true;
                }
                comm.EnableMessageRouting();
                Output("Message routing activated.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnMsgRoutingOff_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Disable message routing
                comm.DisableMessageRouting();
                if (registerMessageReceived)
                {
                    comm.MessageReceived -= new MessageReceivedEventHandler(comm_MessageReceived);
                    registerMessageReceived = false;
                }
                Output("Message routing deactivated.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnMsgMemStatus_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetMessageStorage();
            try
            {
                // Get memory status of the storage
                MemoryStatus status = comm.GetMessageMemoryStatus(storage);
                int percentUsed = (status.Total > 0) ? (int)((double)status.Used / (double)status.Total * 100) : 0;
                Output(string.Format("Message memory status: {0} of {1} used ({2}% used, {3}% free)",
                    status.Used, status.Total, percentUsed, 100 - percentUsed));
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnGetSMSC_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                // Get the SMSC address
                Cursor.Current = Cursors.WaitCursor;
                AddressData data = comm.GetSmscAddress();
                Output("SMSC address: " + data.Address);
                Output("Address type: " + data.TypeOfAddress.ToString());
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnSetSMSC_Click(object sender, System.EventArgs e)
        {
            // Get the address
            string address = txtNewSMSC.Text;

            // Get also the type, if selected
            int typeOfAddress = 0;
            if (chkNewSMSCType.Checked)
            {
                try
                {
                    typeOfAddress = int.Parse(txtNewSMSCType.Text);
                }
                catch (Exception ex)
                {
                    ShowException(ex);
                    return;
                }
            }

            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Set the SMSC address
                if (chkNewSMSCType.Checked)
                    comm.SetSmscAddress(new AddressData(address, typeOfAddress));
                else
                    comm.SetSmscAddress(address);

                Output("New SMSC address set.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion

        #region Manage phonebook

        private void btnExportPhonebook_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetPhonebookStorage();
            try
            {
                // Read and serialize all phonebook entries from storage into an XML file.
                PhonebookEntry[] entries = comm.GetPhonebook(storage);
                Output(entries.Length.ToString() + " entries read.");

                const string filename = @"C:\phonebook.xml";
                Output("Exporting the phonebook entries to " + filename + "...");
                System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(typeof(PhonebookEntry[]));
                System.IO.StreamWriter sw = System.IO.File.CreateText(filename);
                ser.Serialize(sw, entries);
                sw.Close();
                Output("Done.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnImportPhonebook_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetPhonebookStorage();
            try
            {
                // Load and copy all saved phonebook entries to storage.
                const string filename = @"C:\phonebook.xml";
                Output("Importing phonebook entries from " + filename + "...");
                System.IO.StreamReader sr = System.IO.File.OpenText(filename);
                System.Xml.Serialization.XmlSerializer ser = new System.Xml.Serialization.XmlSerializer(typeof(PhonebookEntry[]));
                object temp = ser.Deserialize(sr);
                sr.Close();
                PhonebookEntry[] entries = (PhonebookEntry[])temp;
                Output(entries.Length.ToString() + " entries to create.");
                foreach (PhonebookEntry entry in entries)
                {
                    comm.CreatePhonebookEntry(entry, storage);
                    Output("Entry \"" + entry.Text + "\" created.");
                }
                Output("Done.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnDumpPhonebook_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetPhonebookStorage();
            try
            {
                // Read the whole phonebook from the storage
                PhonebookEntry[] entries = comm.GetPhonebook(storage);
                if (entries.Length > 0)
                {
                    // Display the entries read
                    foreach (PhonebookEntry entry in entries)
                    {
                        Output(string.Format("{0,-20}{1}", entry.Number, entry.Text));
                    }
                }
                Output(string.Format("{0,9} entries read.", entries.Length.ToString()));
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnDeletePhonebookEntry_Click(object sender, System.EventArgs e)
        {
            int index;
            try
            {
                index = int.Parse(txtDelPbIndex.Text);
            }
            catch (Exception ex)
            {
                ShowException(ex);
                return;
            }

            if (!Confirmed()) return;
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetPhonebookStorage();
            try
            {
                // Delete the phonebook entry with the specified index from storage
                comm.DeletePhonebookEntry(index, storage);
                Output("Entry deleted.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnDeletePhonebook_Click(object sender, System.EventArgs e)
        {
            if (!Confirmed()) return;
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetPhonebookStorage();
            try
            {
                // Delete all phonebook entries from storage
                comm.DeleteAllPhonebookEntries(storage);
                Output("Phonebook deleted.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnCreatePbEntry_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetPhonebookStorage();
            try
            {
                // Create the phonebook entry in storage
                comm.CreatePhonebookEntry(new PhonebookEntry(0, txtPbNumber.Text,
                    txtPbNumber.Text.StartsWith("+") ? AddressType.InternationalPhone : AddressType.UnknownPhone,
                    txtPbName.Text), storage);
                Output("Phonebook created.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnPbStorages_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get the supported phonebook storages
                string[] storages = comm.GetPhonebookStorages();
                Output("Supported phonebook storages: " + MakeArrayString(storages));
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnPbMemStatus_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            string storage = GetPhonebookStorage();
            try
            {
                // Get memory status of the phonebook storage
                MemoryStatus status = comm.GetPhonebookMemoryStatus(storage);
                int percentUsed = (status.Total > 0) ? (int)((double)status.Used / (double)status.Total * 100) : 0;
                Output(string.Format("Phonebook memory status: {0} of {1} used ({2}% used, {3}% free)",
                    status.Used, status.Total, percentUsed, 100 - percentUsed));
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion

        #region Smart Messaging

        private OutgoingSmsPdu[] CreateConcatMessage(string message, string number, bool unicode, bool showParts)
        {
            OutgoingSmsPdu[] pdus = null;
            try
            {
                if (!unicode)
                {
                    Output("Creating concatenated message.");
                    pdus = SmartMessageFactory.CreateConcatTextMessage(message, number);
                }
                else
                {
                    Output("Creating concatenated Unicode message.");
                    pdus = SmartMessageFactory.CreateConcatTextMessage(message, true, number);
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
                return null;
            }

            if (pdus.Length == 0)
            {
                Output("Error: No PDU parts have been created!");
                Output("");
                return null;
            }
            else
            {
                if (showParts)
                {
                    for (int i = 0; i < pdus.Length; i++)
                    {
                        Output("Part #" + (i + 1).ToString() + ": " + Environment.NewLine + pdus[i].ToString());
                    }
                }
                Output(pdus.Length.ToString() + " message part(s) created.");
                Output("");
            }

            return pdus;
        }

        private void SendMultiple(OutgoingSmsPdu[] pdus)
        {
            int num = pdus.Length;
            Cursor.Current = Cursors.WaitCursor;
            try
            {
                // Send the created messages
                int i = 0;
                foreach (OutgoingSmsPdu pdu in pdus)
                {
                    i++;
                    Output("Sending message " + i.ToString() + " of " + num.ToString() + "...");
                    comm.SendMessage(pdu);
                }
                Output("Done.");
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
                Output("Message sending aborted because of an error.");
                Output("");
            }

            Cursor.Current = Cursors.Default;
        }




        private OutgoingSmsPdu[] CreateOperatorLogoMsg(Bitmap bitmap, string number, string mcc, string mnc)
        {
            Output("Creating operator logo message.");
            OutgoingSmsPdu[] pdus = null;
            try
            {
                byte[] logo;
                if (bitmap != null)
                {
                    logo = SmartMessageFactory.CreateOperatorLogo(new OtaBitmap(bitmap), mcc, mnc);
                }
                else
                {
                    // Empty operator logo
                    Output("Empty operator logo is used.");
                    logo = SmartMessageFactory.EmptyOperatorLogo;
                }
                pdus = SmartMessageFactory.CreateOperatorLogoMessage(logo, number);
            }
            catch (Exception ex)
            {
                ShowException(ex);
                return null;
            }

            Output(pdus.Length.ToString() + " message part(s) created.");
            Output("");

            return pdus;
        }





        #endregion


        #region Text mode
        private void btnGetCharset_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get the currently selected text mode character set
                string charset = comm.GetCurrentCharacterSet();
                Output("Current text mode character set: " + charset);
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;

        }

        private void btnCharsets_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get the supported text mode character sets
                string[] sets = comm.GetSupportedCharacterSets();
                Output("Supported text mode character sets: " + MakeArrayString(sets));
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }


        #endregion

        #region Network

        private void GetOperator_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Retrieve info about the currently selected operator
                OperatorInfo info = comm.GetCurrentOperator();
                if (info != null)
                {
                    Output("Operator info:");
                    Output("  Format: " + info.Format);
                    Output("  Operator: " + info.TheOperator);
                    Output("  Access Technology: " + info.AccessTechnology);
                    Output("");
                }
                else
                {
                    Output("There is currently no operator selected!");
                    Output("");
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void GetOpSelectionMode_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get the current operator selection mode
                OperatorSelectionMode mode = comm.GetOperatorSelectionMode();
                Output("Current operator selection mode: {0}", mode);
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnListOperators_Click(object sender, System.EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // List the operators detected by the phone
                OperatorInfo2[] info2 = comm.ListOperators();
                Output("Operator list:");
                Output("-------------------------------------------------------------------");
                foreach (OperatorInfo2 info in info2)
                {
                    Output("Status: {0}\r\nLong alphanumeric: {1}\r\nShort alphanumeric: {2}\r\n" +
                        "Numeric: {3}\r\nAccess Technology: {4}",
                        info.Status, info.LongAlphanumeric, info.ShortAlphanumeric, info.Numeric, info.AccessTechnology);
                    Output("");
                }
                Output("-------------------------------------------------------------------");
                Output("{0} operator(s) found.", info2.Length.ToString());
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        private void btnSubscriberNumbers_Click(object sender, EventArgs e)
        {
            Cursor.Current = Cursors.WaitCursor;

            try
            {
                // Get the subscriber numbers
                SubscriberInfo[] info2 = comm.GetSubscriberNumbers();
                foreach (SubscriberInfo info in info2)
                {
                    Output("{0,-20}Type {1}, Speed {2}, Service {3}, ITC {4}, Alpha {5}",
                        info.Number, info.Type, info.Speed, info.Service, info.Itc, info.Alpha);
                }
                Output("{0,9} number(s) found.", info2.Length.ToString());
                Output("");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }

            Cursor.Current = Cursors.Default;
        }

        #endregion

        #region Custom commands

        private void btnGetProtocol_Click(object sender, EventArgs e)
        {

        }

        #endregion

        private void chkEnableLogging_CheckedChanged(object sender, System.EventArgs e)
        {
            try
            {
                if (chkEnableLogging.Checked)
                {
                    comm.LoglineAdded += new LoglineAddedEventHandler(comm_LoglineAdded);
                    Output("Logging enabled.");
                    Output("");
                }
                else
                {
                    comm.LoglineAdded -= new LoglineAddedEventHandler(comm_LoglineAdded);
                    Output("Logging disabled.");
                    Output("");
                }
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private void txtClearOutput_Click(object sender, System.EventArgs e)
        {
            txtOutput.Clear();
        }

        /////////////////////// Event handlers for events from comm object

        private void comm_LoglineAdded(object sender, LoglineAddedEventArgs e)
        {
            Output("{0,-10} {1}", e.Level, e.Text);
        }

        private void comm_MessageReceived(object sender, MessageReceivedEventArgs e)
        {
            try
            {
                IMessageIndicationObject obj = e.IndicationObject;
                if (obj is MemoryLocation)
                {
                    MemoryLocation loc = (MemoryLocation)obj;
                    Output(string.Format("New message received in storage \"{0}\", index {1}.",
                        loc.Storage, loc.Index));
                    Output("");
                    return;
                }
                if (obj is ShortMessage)
                {
                    ShortMessage msg = (ShortMessage)obj;
                    SmsPdu pdu = comm.DecodeReceivedMessage(msg);
                    Output("New message received:");
                    ShowMessage(pdu);
                    Output("");
                    return;
                }
                Output("Error: Unknown notification object!");
            }
            catch (Exception ex)
            {
                ShowException(ex);
            }
        }

        private delegate void ConnectedHandler(bool connected);
        private void OnPhoneConnectionChange(bool connected)
        {
            lblNotConnected.Visible = !connected;
        }

        private void comm_PhoneConnected(object sender, EventArgs e)
        {
            this.Invoke(new ConnectedHandler(OnPhoneConnectionChange), new object[] { true });
        }

        private void comm_PhoneDisconnected(object sender, EventArgs e)
        {
            this.Invoke(new ConnectedHandler(OnPhoneConnectionChange), new object[] { false });
        }

        /////////////////////// Helpers

        private string MakeArrayString(string[] array)
        {
            System.Text.StringBuilder str = new System.Text.StringBuilder();
            foreach (string item in array)
            {
                if (str.Length > 0)
                    str.Append(", ");
                str.Append(item);
            }

            return str.ToString();
        }

        private void ShowMessage(SmsPdu pdu)
        {
            if (pdu is SmsSubmitPdu)
            {
                // Stored (sent/unsent) message
                SmsSubmitPdu data = (SmsSubmitPdu)pdu;
                Output("SENT/UNSENT MESSAGE");
                Output("Recipient: " + data.DestinationAddress);
                Output("Message text: " + data.UserDataText);
                Output("-------------------------------------------------------------------");
                return;
            }
            if (pdu is SmsDeliverPdu)
            {
                // Received message
                SmsDeliverPdu data = (SmsDeliverPdu)pdu;
                Output("RECEIVED MESSAGE");
                Output("Sender: " + data.OriginatingAddress);
                Output("Sent: " + data.SCTimestamp.ToString());
                Output("Message text: " + data.UserDataText);
                Output("-------------------------------------------------------------------");
                return;
            }
            if (pdu is SmsStatusReportPdu)
            {
                // Status report
                SmsStatusReportPdu data = (SmsStatusReportPdu)pdu;
                Output("STATUS REPORT");
                Output("Recipient: " + data.RecipientAddress);
                Output("Status: " + data.Status.ToString());
                Output("Timestamp: " + data.DischargeTime.ToString());
                Output("Message ref: " + data.MessageReference.ToString());
                Output("-------------------------------------------------------------------");
                return;
            }
            Output("Unknown message type: " + pdu.GetType().ToString());
        }

        private string StatusToString(PhoneMessageStatus status)
        {
            // Map a message status to a string
            string ret;
            switch (status)
            {
                case PhoneMessageStatus.All:
                    ret = "All";
                    break;
                case PhoneMessageStatus.ReceivedRead:
                    ret = "Read";
                    break;
                case PhoneMessageStatus.ReceivedUnread:
                    ret = "Unread";
                    break;
                case PhoneMessageStatus.StoredSent:
                    ret = "Sent";
                    break;
                case PhoneMessageStatus.StoredUnsent:
                    ret = "Unsent";
                    break;
                default:
                    ret = "Unknown (" + status.ToString() + ")";
                    break;
            }
            return ret;
        }
        Message objMsg = new Message();
        public DataTable Top1Message()
        {
            return objMsg.tblMessage_Select_Top1();
        }
        public DataTable LoadDataAll()
        {
            return objMsg.tblMessage_Select_All();
        }
        int ckMonney = 0;
        private void timer1_Tick(object sender, EventArgs e)
        {
            DataTable table = new DataTable();
            if (getStatusIP() == true)
            {
                table = Top1Message();
            }
            else
            {
                table = LoadDataAll();
            }
            if (table.Rows.Count > 0)
            {
                Cursor.Current = Cursors.WaitCursor;

                string PHONE_NUMBER = table.Rows[0]["PhoneNumber"].ToString();
                string CONTENT = table.Rows[0]["Content"].ToString();
                string MESSAGE_ID = table.Rows[0]["ID"].ToString();
                string STATUS = table.Rows[0]["IsSent"].ToString();
                try
                {
                    // Send an SMS message

                    SmsSubmitPdu pdu;
                    if (!chkUnicode.Checked)
                    {


                        pdu = new SmsSubmitPdu(CONTENT, PHONE_NUMBER);
                        objMsg.UpdateMessage(MESSAGE_ID);
                    }
                    else
                    {
                        // Send message in Unicode format
                        byte dcs = (byte)DataCodingScheme.GeneralCoding.Alpha16Bit;
                        pdu = new SmsSubmitPdu(CONTENT, PHONE_NUMBER, dcs);
                    }

                    // Request immediate display (alert)
                    if (chkAlert.Checked)
                        pdu.DataCodingScheme |= (byte)DataCodingScheme.GeneralCoding.Class0;

                    // Send message to a destination port
                    if (chkDestinationPort.Checked)
                    {
                        ushort destinationPort = ushort.Parse(txtDestinationPort.Text);
                        byte[] userDataHeader = SmartMessageFactory.CreatePortAddressHeader(destinationPort);
                        pdu.AddUserDataHeader(userDataHeader);
                    }

                    // Use an explicit SMSC if this is set
                    if (chkSMSC.Checked)
                        pdu.SmscAddress = txtSMSC.Text;

                    // If a status report should be generated, set that here
                    if (chkReport.Checked)
                        pdu.RequestStatusReport = true;

                    // Send the same message multiple times if this is set
                    int times = chkMultipleTimes.Checked ? int.Parse(txtSendTimes.Text) : 1;

                    // If SMS batch mode should be activated, do it immediately before sending the first message
                    if (chkSmsBatchMode.Checked)
                        comm.EnableTemporarySmsBatchMode();

                    // Send the message the specified number of times
                    for (int i = 0; i < times; i++)
                    {
                        comm.SendMessage(pdu);

                        Output("GSM2: Message {0} of {1} sent to {2} at {3}", i + 1, times, PHONE_NUMBER, DateTime.Now.ToString());
                        ckMonney = 0;
                        //  Output("Message {0} of {1} sent.", i + 1, times);
                    }




                }
                catch (Exception ex)
                {

                    ShowException(ex);
                    Output(MESSAGE_ID + " " + PHONE_NUMBER + " " + String.Format("{0:dd/MM/yyyyy}", DateTime.Now));
                    if (STATUS == "0")
                    {
                        String cmdText = "UPDATE tblTransaction SET IsSent=2, SentDate=GETDATE() where ID=" + MESSAGE_ID + " ";
                        new ConnectSQL().ExcutedCMD(cmdText);
                        ckMonney += 1;
                        if (ckMonney == 3)
                        {
                            this.Close();
                        }
                    } 
                    if (STATUS == "2")
                    {
                        String cmdText = "UPDATE tblTransaction SET IsSent=3, SentDate=GETDATE() where ID=" + MESSAGE_ID + " ";
                        new ConnectSQL().ExcutedCMD(cmdText);
                        ckMonney += 1;
                        if (ckMonney == 3)
                        {
                            this.Close();
                        }
                    }
                }

                Cursor.Current = Cursors.Default;
            }
        }

        public bool getStatusIP()
        {
            Message msg = new Message();
            try
            {
                DataSet ds = msg.getSttIP("10.92.184.40");
                if (ds.Tables[0].Rows[0]["Status"].ToString() != "0" && ds.Tables[0].Rows[0]["RunSMS"].ToString() != "0")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        private void txtOutput_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
