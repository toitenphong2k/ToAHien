﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace SendMailAttendance
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string Dir_Curent = Directory.GetCurrentDirectory();
            DayOfWeek curent_day_of_week = DateTime.Now.DayOfWeek;
            DateTime yesterday = DateTime.Now.AddDays(-1);
            //DateTime yesterday = DateTime.Now;
            DateTime days_ago = DateTime.Now.AddDays(-3);
            List<DateTime> ListDate = new List<DateTime>();
            ListDate.Add(yesterday);
            ListDate.Add(days_ago);
            IPHostEntry host;
            IPAddress ipAddress = IPAddress.Parse("0.0.0.0");
            string hostName = "";
            try
            {
                host = Dns.GetHostEntry(Dns.GetHostName());
                ipAddress = host.AddressList
                                   .Where(ip => ip.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
                                   .FirstOrDefault();
                hostName = Dns.GetHostName();
            }
            catch (Exception ex)
            {
                writecsv($"{Dir_Curent}\\LOGNG\\{DateTime.Now.ToString("dd_MM_yyyy")}.txt", $"{DateTime.Now.ToString("HH:mm:ss")}: {ex.Message}");
            }
            if (curent_day_of_week != DayOfWeek.Sunday && curent_day_of_week != DayOfWeek.Saturday)
            {
                DataTable dt = new DataTable();
                try
                {
                    dt = Db_ConnectPSNV.StoreFillDS("Check_SendMail_IS_OK", CommandType.StoredProcedure, "Gửi Mail quên quẹt thẻ", DateTime.Now.ToString("yyyy-MM-dd"));
                }
                catch (Exception ex)
                {

                    writecsv($"{Dir_Curent}\\LOGNG\\{DateTime.Now.ToString("dd_MM_yyyy")}.txt", $"{DateTime.Now.ToString("HH:mm:ss")}: Store: Check_SendMail_IS_OK {ex.Message}");
                }
                if (dt.Rows.Count == 0)
                {
                    int vl = 0;
                    foreach (DateTime item in ListDate)
                    {
                        try
                        {
                            string query = SendMailForgetScan(item);
                            writecsv($"{Dir_Curent}\\LOGOK\\{DateTime.Now.ToString("dd_MM_yyyy")}.txt", $"{DateTime.Now.ToString("HH:mm:ss")}: DataOf({item.ToString("dd-MM-yyyy")}) {query}");
                        }
                        catch (Exception ex)
                        {
                            vl++;
                            writecsv($"{Dir_Curent}\\LOGNG\\{DateTime.Now.ToString("dd_MM_yyyy")}.txt", $"{DateTime.Now.ToString("HH:mm:ss")}: DataOf({item.ToString("dd-MM-yyyy")}) {ex.Message}");
                        }
                    }
                    try
                    {
                        if (vl == 0)
                        {
                            Db_ConnectPSNV.excutenonquerry("Insert_Data_SendMail", CommandType.StoredProcedure, "Gửi Mail quên quẹt thẻ", DateTime.Now.ToString("yyyy-MM-dd"), hostName, ipAddress.ToString(), "OK");
                        }
                        else
                        {
                            Db_ConnectPSNV.excutenonquerry("Insert_Data_SendMail", CommandType.StoredProcedure, "Gửi Mail quên quẹt thẻ", DateTime.Now.ToString("yyyy-MM-dd"), hostName, ipAddress.ToString(), "NG");
                        }
                    }
                    catch (Exception ex)
                    {

                        writecsv($"{Dir_Curent}\\LOGNG\\{DateTime.Now.ToString("dd_MM_yyyy")}.txt", $"{DateTime.Now.ToString("HH:mm:ss")}: Store: Insert_Data_SendMail {ex.Message}");
                    }
                }
            }
            else
            {
                writecsv($"{Dir_Curent}\\LOGOK\\{DateTime.Now.ToString("dd_MM_yyyy")}.txt", $"{DateTime.Now.ToString("HH:mm:ss")}: {curent_day_of_week}-No Run");
            }
        }
        static string SendMailForgetScan(DateTime DateSelect)
        {

            DataTable dataforget = Db_connectPV.querygettable(Query_Getdata_PV(DateSelect.ToString("yyyy-MM-dd")));
            if (dataforget.Rows.Count < 300)
            {
                DataTable useractive = Db_ConnectPSNV.querygettable("SELECT  [UserID] FROM hrdigital_userlogin where IsDisable <> 1 or IsDisable is null");
                DataTable userisrequest = Db_ConnectPSNV.querygettable($"SELECT  [UserID_Request] FROM Eleave_Request_InOut where WorkDate = '{DateSelect.ToString("yyyy-MM-dd")}'");


                var list_id = dataforget.AsEnumerable().GroupBy(gr => new { ID = gr["CodeEmp"].ToString() }).Select(x => x.Key.ID).ToList();


                var activeUserIds = useractive.AsEnumerable()
                        .Select(row => row["UserID"].ToString())
                        .ToHashSet(); 

                
                var useridhaverequest = userisrequest.AsEnumerable().Select(row => row["UserID_Request"].ToString())
                        .ToHashSet();


                var filteredListId = list_id
                    .Where(id => activeUserIds.Contains(id))
                    .ToList();


                var finallist = filteredListId.Where(id=> !useridhaverequest.Contains(id)).ToList();






                string IDString = string.Join("','", finallist);
                IDString = "'" + IDString + "'";
                string query = Query_Getdata_PSNV(IDString);
                DataTable data_mail_yesterday = Db_ConnectPSNV.querygettable(query);
                List<string> ListMail = data_mail_yesterday.AsEnumerable().Where(c => c["Mail"].ToString().Contains("@")).Select(data => data["Mail"].ToString()).ToList();
                //SendMail("Xác nhận chấm công", $"Bạn có dữ liệu chấm công bất thường ngày {DateSelect.ToString("dd-MM-yyyy")}", ListMail);

                string body = "";
                body += "<h2> Thông Báo Từ Hệ Thống Quản Lý Nhân Sự </h2>";

                body += $"<p style=\"margin:0px\" >Hệ thống quản lý nhân sự gửi thông báo đề nghị xác nhận thông tin giờ vào/ giờ ra công ty ngày <strong> {DateSelect.ToString("dd-MM-yyyy")} </strong></p>";
                body += $"<p style=\"margin:0px\" >Anh/chị hãy xác nhận thông tin trên HR DIGITAL tại máy tính hoặc laptop của công ty để đảm bảo ngày công của mình.</p>";
                body += "<p style=\"margin:0px\">Đây là link để truy cập:</p>";
                body += "<a href=\"http://10.92.184.24:9006/\">HR DIGITAL</a><br />";

                body += "<p style=\"margin-top:10px; font-style:italic; font-weight:600\" class=\"contact-info\">Nếu bạn có bất kỳ thắc mắc nào, vui lòng liên hệ Quản lý trực tiếp hoặc Phòng Hành chính - Nhân sự để được hỗ trợ.</p>";
                body += "<p style=\"margin:0px;font-style:italic; font-weight:600 \"class=\"contact-info\">(Số điện thoại: 043 955 0067 máy lẻ 2214)</p>";

                body += "<p style=\"margin:0px;font-style:italic; font-weight:600 \"class=\"contact-info\">Đây là email được gửi từ hệ thống, vui lòng không phải hồi.</p>";

                body += "<p style=\"margin-top:20px\">Trân trọng,</p>";

                SendMail("THÔNG BÁO YÊU CẦU XÁC NHẬN GIỜ RA/ GIỜ VÀO", body, ListMail);

                return query;
            }
            else
            {
                return $"{dataforget.Rows.Count} dữ liệu quên quẹt thẻ nên không gửi";
            }
        }
        private static void SendMail(string Subject, string body, List<string> ListMail)
        {

             DataTable dt = Db_ConnectPSNV.querygettable("SELECT top (100) [Mail]FROM ListMailCC");


            System.Net.Mail.SmtpClient objClient = new System.Net.Mail.SmtpClient("157.8.1.131");
            System.Net.Mail.MailAddress mail = new System.Net.Mail.MailAddress("PSNV.HCNS@vn.panasonic.com", "HR Digital System");
            System.Net.Mail.MailMessage objMessage = new System.Net.Mail.MailMessage();
            objMessage.From = mail;
            objMessage.Subject = Subject;
            objMessage.Body = body;



            foreach (DataRow item in dt.Rows)
            {
                objMessage.CC.Add(item["Mail"].ToString().Trim());
            }


            foreach (string Mail in ListMail)
            {
                string[] arraymail = Mail.Split(';');

                for (int i = 0; i < arraymail.Length; i++)
                {
                    if (arraymail[i].Contains("@"))
                    {
                        objMessage.Bcc.Add(arraymail[i].Trim());
                    }
                }
            }
            objMessage.IsBodyHtml = true;
            objClient.Send(objMessage);
        }
        private static void writecsv(string filepath, string data)
        {
            try
            {
                using (var sr = new StreamWriter(filepath, true, Encoding.UTF8))
                {
                    sr.WriteLine(data);
                }
            }
            catch (Exception)
            {

            }

        }
        static string Query_Getdata_PV(string dateselect)
        {
            string query = "SELECT" +
                  "[CodeEmp]," +
                  "[ProfileName]," +
                  "[E_DIVISION]," +
                   "[E_DEPARTMENT]," +
                    "[Line]," +
                  "[WorkDate]," +
                  "[InTime1]," +
                  "[OutTime1]," +
                  "[LateDuration1]," +
                  "[EarlyDuration1]," +
                  "[Ca]," +
                  "[MaNgayNghi]," +
                  "[TypeVN]" +
                  "FROM View_ThongTinChamCong_PSNV (nolock)" +
                  $"where  " +
                  $"WorkDate = '{dateselect}'" +

                  $" and Ca is not Null " +
                  $"and Ca <> 'ML' " +
                  $"and MaNgayNghi is null " +
                  $"and E_BRANCH = 'PSNV' " +
                  $"and  (TypeVN = N'Thiếu Cả In Out' or TypeVN = N'Thiếu Out' or TypeVN = N'Thiếu In' or LateDuration1 > 0 or EarlyDuration1 > 0 )";

            return query;
        }
        static string Query_Getdata_PSNV(string listid)
        {
            string query = $"SELECT [Mail] FROM hrdigital_userinfor (nolock) where UserID in ({listid}) and Mail <> '' and Mail is not NULL";
            return query;
        }
    }
}
